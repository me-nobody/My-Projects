for (name in new_lst){
  x<-get(name) # get the character as a variable
  print(dim(x))
  new_name <-paste(name,'_body',sep="")
  new_var<-get(new_name)
  new_var<-x[,c("FSC","SSC")]
  }
