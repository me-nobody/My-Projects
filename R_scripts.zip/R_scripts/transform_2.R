for (item in objects()){
  #item<-get(item)
  if (class(get(item))=='matrix'){
  item<-as.data.frame(get(item))
  }
  
}
