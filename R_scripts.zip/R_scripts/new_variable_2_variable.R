# set data directory as working directory
# ensure only matrix files are in current directory
file.list<-ls()
vector_ls<-c()
# in the loop below, only vector with filenames ending as smpl is created
for (variable in file.list){
  if (class(get(variable[1]))=="matrix"){ # check if file type is a matrix
    var_len<-nchar(variable) # length of variable
    clipped_name<-substring(variable,1,(var_len-4)) # collect the first half of the name
    new_name <-paste(clipped_name,'smpl',sep="") # add "mtrx" extension to file name
    vector_ls<-c(vector_ls,new_name)
  }
}
# in the loop below, the index of the file is needed 
# in the loop below, the dataframes are generated
for (num in seq_along(file.list)){
  pattern=substr(file.list[num],1,nchar(file.list[num])-4)
  if (class(get(file.list[num]))=="matrix"){ # check if file type is a matrix
    x<-get(file.list[num])
    smpl=sample(dim(x)[1],10000,replace = TRUE)
    y<-x[smpl,]
    y<-as.data.frame(y)
    if (str_detect(vector_ls[num],pattern)){ # is the file in vector same as in file list
     
      assign(vector_ls[num],y) # assigns the character as a variable
    }
  }
}

