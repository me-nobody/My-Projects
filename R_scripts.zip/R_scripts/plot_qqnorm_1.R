dev.new()
par(mfrow=c(4,4))
for (i in 1:ncol(aa[,1: ncol(aa) - 1 ])){  
  qqnorm(aa[, i], main = names(aa[i]))
  qqline(aa[, i])
}
# aa is the name of dataframe
#dev.copy(png,'plot.png',bg='white')
#dev.off()
#dev.flush()    
