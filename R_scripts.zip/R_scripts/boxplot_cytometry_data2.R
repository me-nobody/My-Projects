dev.new()
par(bg='white',mfrow=c(1,2))
boxplot(s_c_2_data[,'FL1'],s_c_2_data[,'FL3'],
     main='live/dead Control', cex.lab=1.2,names=c('FL1','FL3'),log='y',
     col=c('green','red'),ylab='Intensity')
boxplot(s_h_2_data[,'FL1'],s_h_2_data[,'FL3'],
        main='live/dead H2O2', cex.lab=1.2,names=c('FL1','FL3'),log='y',
        col=c('green','red'),ylab='Intensity')
dev.copy(png,'live_dead_boxplot2.png',bg='white')
dev.off()
dev.flush()    
