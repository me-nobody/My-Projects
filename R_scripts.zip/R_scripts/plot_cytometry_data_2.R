dev.new()
par(bg='white')
plot(sp_sc1$FL1,sp_sc1$FL3,xlab='FL1',ylab='FL3',
     main='fsc log',pch=20,cex=0.3,col=rgb(red=0,green=1,blue = 0,alpha=0.5),
     cex.lab=1,log='x')
points(sp_sh1$FL1,sp_sh1$FL3,pch=20,cex=0.3,col=rgb(red=1,green=0,blue = 0,alpha=0.5))
legend(8,5,legend = c("Control","H2O2"),col=c("green","red",cex=0.2),lty=1,pch=21)
#dev.copy(png,'plot.png',bg='white')
dev.off()
dev.flush()    


