dev.new()
par(bg='white',mfrow=c(1,2))
boxplot(bodipy_Ecoli_cnt_2_smpl[,'FL1'],bodipy_Ecoli_gamma_2_smpl[,'FL1'],
     main='bodipy Ecoli radiation', cex.lab=1.4,cex.axis=1.4,names=c('CNTL','GAMMA'),log='y',
     col=c('green','yellow'),ylab='Intensity',las=3)
dev.copy(png,'bodipy_Ecoli_gamma_2.png',bg='white')
dev.off()
dev.flush()    
