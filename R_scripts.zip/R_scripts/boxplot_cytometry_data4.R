dev.new()
par(bg='white',mfrow=c(1,2))
boxplot(sp_uc1[,'FL1'],sp_uh1[,'FL1'],
     main='Unstained', cex.lab=1.2,names=c('CNTL','H2O2'),log='y',
     col=c('white','white'),ylab='Intensity',las=3,cex.axis=1.4)
dev.copy(png,'Unstained_boxplot.png',bg='white')
dev.off()
dev.flush()    
