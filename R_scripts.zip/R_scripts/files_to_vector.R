file_vector<-character()
for (name in dir()){ 
  start<-nchar(name) # number of characters
  new_name<-substring(name,1,(start-4)) # custom range of letters
  nm <-paste(new_name,'_file',sep="")
  print(nm)
  file_vector<-c(file_vector,nm)
  }
  