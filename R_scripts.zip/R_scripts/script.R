for(i in seq_along(files)){
  vector[i]<-as.data.frame(vector[i])
  vector[i]<-read.FCS(files[i])
              }
  
    