file.list<-list.files()
for(num in seq_along(file.list)){
  print(substring(file.list[num],1,nchar(file.list[num])-4))
}