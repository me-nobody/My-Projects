dev.new()
par(bg='white',mfrow=c(1,2))
boxplot(syto_BT_cnt_3_smpl[,'FL1'],syto_BT_cnt_3_smpl[,'FL3'],
     main='live/dead Control', cex.lab=1.4,cex.axis=1.4,names=c('SYTO9','PI'),log='y',
     col=c('green','red'),ylab='Intensity',las=3)
boxplot(syto_BT_gamma_3_smpl[,'FL1'],syto_BT_gamma_3_smpl[,'FL3'],
        main='live/dead H2O2', cex.lab=1.4,cex.axis=1.4,names=c('SYTO9','PI'),log='y',
        col=c('green','red'),ylab='Intensity',las=3)
dev.copy(png,'live_dead_BT_gamma_3.png',bg='white')
dev.off()
dev.flush()    
