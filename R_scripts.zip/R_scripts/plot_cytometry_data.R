dev.new()
par(bg='white')
plot(b_c_1_data[,'FL1'],b_c_1_data[,'FL3'],xlab='FL1 (SYTO 9)',ylab='FL3 (PI)',
     main='BODIPY live/dead',pch=20,cex=1,xlim=c(0,10),col=rgb(red=0,green=1,blue = 0,alpha=0.5),
     cex.lab=1.2,log='y',ylim=c(0.15,8))
points(b_h_1_data[,'FL1'],b_h_1_data[,'FL3'],pch=20,cex=1,col=rgb(red=1,green=0,blue = 0,alpha=0.5))
legend(8,5,legend = c("Control","H2O2"),col=c("green","red",cex=0.2),lty=1,pch=21)
dev.copy(png,'plot.png',bg='white')
dev.off()
dev.flush()    

