dev.new()
par(bg='white',mfrow=c(1,2))
boxplot(sp_sc1[,'FL1'],sp_sc1[,'FL3'],
     main='live/dead Control', cex.lab=1.4,cex.axis=1.4,names=c('SYTO9','PI'),log='y',
     col=c('green','red'),ylab='Intensity',las=3)
boxplot(sp_sh1[,'FL1'],sp_sh1[,'FL3'],
        main='live/dead H2O2', cex.lab=1.4,cex.axis=1.4,names=c('SYTO9','PI'),log='y',
        col=c('green','red'),ylab='Intensity',las=3)
dev.copy(png,'sample_live_dead_boxplot1.png',bg='white')
dev.off()
dev.flush()    
