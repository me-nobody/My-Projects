# set working directory to where files are
# this for loop creates a vector of file names
file_vector<-character()
for (name in dir()){ 
  start<-nchar(name) # number of characters
  new_name<-substring(name,1,(start-4)) # custom range of letters
  nm <-paste(new_name,'_file',sep="")
  print(nm)
  file_vector<-c(file_vector,nm)
}
# this for loop reads data from files and creates dataframes
files<-list.files()
for (num in  seq_along(files)){
  if (str_detect(files[num],"fcs")){ # does file have .fcs
    pattern=substr(files[num],1,nchar(files[num])-4)
    if (str_detect(file_vector[num],pattern)){ # is the file in vector same as in file list
      print(file_vector[num])
      assign(file_vector[num],read.FCS(files[num])) # assigns the character as a variable
      }
  }
  
}

  