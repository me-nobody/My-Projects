# set data directory as working directory
# ensure only matrix files are in current directory
file.list<-ls()
vector_ls<-c()
for (variable in file.list){
  if (str_detect(variable,"file")){
    var_len<-nchar(variable) # length of variable
    clipped_name<-substring(variable,1,(var_len-4)) # collect the first half of the name
    new_name <-paste(clipped_name,'mtrx',sep="") # add "mtrx" extension to file name
    vector_ls<-c(vector_ls,new_name)
  }
}
# in the loop above, only string to be matched in variable name
# in the loop below, the index of the file is needed 
for (num in  seq_along(file.list)){
  if (str_detect(file.list[num],"file")){ # does file have "file" string in it
    pattern=substr(file.list[num],1,nchar(file.list[num])-4)
    if (str_detect(vector_ls[num],pattern)){ # is the file in vector same as in file list
      temp<-get(file.list[num]) # the string as a variable
      assign(vector_ls[num],temp@exprs) # assigns the character as a variable
    }
  }
}