dev.new()
par(bg='white',mfrow=c(1,2))
boxplot(b_c_1_data[,'FL1'],b_h_1_data[,'FL1'],
     main='BODIPY Control', cex.lab=1.2,names=c('CTRL','H2O2'),log='y',
     col=c('green','yellow'),ylab='Intensity')
boxplot(b_c_2_data[,'FL1'],b_h_2_data[,'FL1'],
        main='BODIPY H2O2', cex.lab=1.2,names=c('CTRL','H2O2'),log='y',
        col=c('green','yellow'),ylab='Intensity')
dev.copy(png,'bodipy_boxplot_correct.png',bg='white')
dev.off()
dev.flush()    
